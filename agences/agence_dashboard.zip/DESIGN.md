---
name: Touis Voyage Brand Identity
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#525657'
  on-tertiary: '#ffffff'
  tertiary-container: '#6b6e70'
  on-tertiary-container: '#eff1f3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-desktop: 40px
  margin-mobile: 20px
  stack-xs: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  stack-xl: 48px
---

## Brand & Style

The brand personality is rooted in "Modern Precision Travel"—combining the reliability of enterprise SaaS with the aspirational allure of high-end global exploration. This design system targets travel agents and high-volume agencies, prioritizing a high-converting interface that feels both powerful and effortless.

The design style is **Corporate / Modern** with a refined **Glassmorphism** touch. It utilizes generous whitespace, crisp structural alignment, and subtle translucency in overlays to evoke a sense of clarity and "airiness" associated with premium travel. The UI should feel fast, responsive, and trustworthy, using the vibrant blue to guide users toward conversion points while maintaining a professional slate-based foundation.

## Colors

The palette is anchored by **Voyage Blue (#2563EB)**, a high-energy primary used for actions and brand reinforcement. To maintain a sophisticated professional tone, we utilize a scale of **Slate Grays** for text hierarchy and structural borders, ensuring the interface remains grounded.

- **Primary:** Voyage Blue is used for CTAs, active states, and focus indicators.
- **Surface:** The background defaults to a clean white (#FFFFFF) with off-white (#F8FAFC) used for secondary containers to provide subtle depth.
- **Text:** Primary text uses Slate 900 (#0F172A) for maximum legibility, while secondary metadata uses Slate 500 (#64748B).
- **Dark Mode Compatibility:** All colors are mapped to a semantic scale; in dark mode, the white surface shifts to Slate 950, and Slate 900 text shifts to Slate 50.

## Typography

The typography system uses **Plus Jakarta Sans** exclusively to reinforce a tech-forward, optimistic aesthetic. The typeface's open counters and modern geometry ensure legibility across dense travel itineraries and complex booking dashboards.

- **Headlines:** Use Bold (700) and Semi-Bold (600) weights with tighter letter spacing (-0.02em) for a high-end editorial feel.
- **Body:** Standardized at 16px for optimal readability. Use Medium (500) for emphasized body snippets.
- **Labels:** Used for navigation items, tags, and table headers. These often utilize Semi-Bold weights to stand out at smaller sizes.
- **Scaling:** On mobile, headline sizes compress to prevent awkward wrapping, while body text remains consistent for accessibility.

## Layout & Spacing

This design system employs a **Fluid Grid** model with a soft 8px baseline rhythm. The layout is designed to handle high information density (itineraries, pricing tables) without feeling cluttered.

- **Grid:** A 12-column grid for desktop with 24px gutters. On tablet, this shifts to 6 columns, and on mobile to 2 columns.
- **Safe Areas:** Global horizontal padding is set to 40px on desktop to give content "room to breathe," which is essential for a high-end feel.
- **Vertical Rhythm:** Elements are grouped using stack variables. Related items (label + input) use 8px spacing, while distinct sections use 48px to clearly define hierarchy.

## Elevation & Depth

To create a "slick" and modern feel, depth is communicated through **Ambient Shadows** and **Tonal Layers** rather than heavy borders.

1.  **Level 0 (Base):** White or Light Gray (#F8FAFC) background.
2.  **Level 1 (Cards):** White background with a subtle "soft" shadow: `0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05)`.
3.  **Level 2 (Floating/Modals):** A more pronounced shadow to indicate interactivity and focus: `0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)`.
4.  **Glass Effect:** Used for fixed navigation bars and sidebars, employing a `backdrop-filter: blur(12px)` and a semi-transparent white stroke (1px, 10% opacity) to catch the light.

## Shapes

The shape language is defined by **Smoothness**. We avoid sharp corners to maintain a friendly, contemporary aesthetic. 

- **Standard Radius:** 8px (0.5rem) for smaller elements like inputs and buttons.
- **Large Radius (rounded-lg):** 16px (1rem) for standard content cards and containers.
- **Extra Large Radius (rounded-xl):** 24px (1.5rem) for main dashboard sections and high-level marketing cards.
- **Pill:** Used exclusively for badges and status indicators to differentiate them from actionable buttons.

## Components

**Buttons**
- **Primary:** Voyage Blue background, White text. 16px border-radius. Subtle hover state: slightly darker blue with a small scale-up (1.02x).
- **Secondary:** Light Slate background with Slate 700 text. No border, just tonal separation.

**Input Fields**
- Sophisticated 1px Slate 200 border. On focus, the border transitions to Voyage Blue with a 3px soft blue glow (ring). Labels are always positioned above the field in Label-MD Semi-Bold.

**Cards**
- Cards are the core of the travel platform. They use 16px or 24px corner radii, a 1px Slate 100 border, and the "Level 1" soft shadow. Images within cards should always inherit the top corner radius.

**Badges (Soft Styling)**
- Status badges (e.g., "Confirmed," "Pending") use a desaturated version of the status color for the background (10% opacity) and the full-saturation color for the text. They are always pill-shaped.

**Iconography**
- Use **Lucide** icons. Maintain a "Regular" stroke weight (2px) to match the typography's weight. Icons should be paired with text for clarity in the sidebar and navigation.

**List Items**
- Interactive list items (like search results) should have a 12px radius and use a background color change (Slate 50) on hover instead of a border change.