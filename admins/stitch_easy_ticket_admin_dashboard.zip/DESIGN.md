---
name: Easy Ticket Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf4'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dde9ff'
  surface-container-highest: '#d5e3fd'
  on-surface: '#0d1c2f'
  on-surface-variant: '#434655'
  inverse-surface: '#233144'
  inverse-on-surface: '#ebf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0d1c2f'
  surface-variant: '#d5e3fd'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  stats-number:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin-mobile: 16px
  container-margin-desktop: 32px
  gutter: 16px
---

## Brand & Style
The design system focuses on precision, trust, and operational efficiency for travel agency management. The brand personality is professional yet approachable, designed to reduce cognitive load in data-heavy environments. 

The visual style follows a **Corporate / Modern** aesthetic with a strong emphasis on **Minimalism**. It utilizes expansive whitespace, a refined color palette, and subtle depth through soft shadows to create a clear information hierarchy. The interface feels "airy" despite the density of SaaS data, ensuring that travel agents can navigate complex itineraries and financial volumes with ease.

## Colors
The palette is rooted in professional reliability. 
- **Primary (#2563eb):** Used for primary actions, active navigation states, and brand-critical indicators.
- **Success (#10b981):** Applied to positive growth metrics (e.g., "Volume d'Affaires" increases) and completed ticket statuses.
- **Warning (#f59e0b):** Reserved for pending confirmations or urgent travel alerts.
- **Neutral/Text (#334155):** A slate-tinted grey used for maximum legibility in body text and labels.
- **Background (#f8fafc):** A cool-toned off-white that prevents screen glare and differentiates surface layers.

## Typography
Inter is used across all levels to ensure crispness on high-density displays. 
- **Headlines:** Use tighter letter spacing for large titles to maintain a modern, "tucked" look.
- **Body Text:** Standard weight for readability. Use `body-sm` for secondary metadata in lists.
- **Labels:** Use uppercase for section headers in sidebars or small captions (e.g., "AGENCES TOTALES").
- **Numbers:** Metric cards should utilize the `stats-number` style to emphasize financial data like business volume.

## Layout & Spacing
This design system utilizes a **Fluid Grid** model with a 12-column layout for desktop and a single-column stack for mobile.

- **Mobile Strategy:** Side navigation collapses into a bottom bar or a hamburger menu. Margins are reduced to 16px to maximize data visualization space.
- **Desktop Strategy:** A fixed sidebar (240px - 280px) houses the primary navigation.
- **Rhythm:** An 8px linear scale is used for all spatial relationships. Elements within cards use `md` (16px) padding, while page headers use `xl` (32px) to create vertical breathing room.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows**. 
- **Base Layer:** The background (#f8fafc) is the lowest surface.
- **Surface Cards:** Dashboard widgets and containers use a white background (#ffffff) with a `shadow-sm` (offset: 0 1px, blur: 2px, opacity: 0.05) to separate them from the background.
- **Interactive States:** Buttons and hovered cards transition to `shadow-md` to provide tactile feedback.
- **Overlays:** Modals and dropdowns use a prominent backdrop blur (12px) to maintain context while focusing user attention.

## Shapes
The shape language is friendly and contemporary, using a **Rounded** (0.5rem) base. 
- **Base Elements:** Buttons, input fields, and small cards use `rounded-lg` (1rem).
- **Large Containers:** Main dashboard widgets and modal windows use `rounded-xl` (1.5rem) to soften the professional interface.
- **Interactive Icons:** Status dots and icon backgrounds may use circular (full-pill) shapes.

## Components
- **Buttons:** Primary buttons use a solid Blue (#2563eb) fill with white text. Secondary buttons use a transparent background with a Slate (#334155) border. Height should be 40px for mobile touch targets.
- **Chips/Badges:** Used for ticket statuses. "Validé" (Success green), "En attente" (Warning amber). Chips should have a light tinted background and a high-contrast text color of the same hue.
- **Input Fields:** Use a 1px border (#e2e8f0) and `rounded-lg`. Focused states use a 2px Blue (#2563eb) outline.
- **Cards:** The primary vehicle for metrics like "Agences Totales." They must feature an icon (Lucide React) in a soft-tinted circle on the left, followed by the metric label and value.
- **Lists:** Data tables should be borderless on the sides, using thin horizontal dividers. Rows must have a hover state background change (#f1f5f9) to assist eye-tracking.
- **Icons:** Use Lucide React icons with a stroke width of 2px. Icons should always be accompanied by labels for clarity in the French language.